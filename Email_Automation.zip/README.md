# Email_Automation_System
test gmail:\n
    Account: nu.example@gmail.com
    \nPassword: 123@Example\n
    Statu: Fully Functuion


import menu
menu.Menu() #import menu module and Call Menu()